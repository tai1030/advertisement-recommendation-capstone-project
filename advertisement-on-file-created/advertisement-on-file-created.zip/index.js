const AWS = require("aws-sdk");
const s3 = new AWS.S3();
const DynamoDB = require("aws-sdk/clients/dynamodb");
const got = require('got');
const request = require('request-promise');
const fileType = require('file-type');

// S3 bucket name
var bucketName = "advertisement-files";

// Load DynamoDB client
const dynamodb = new DynamoDB.DocumentClient({
    region: 'us-east-2'
});

exports.handler = async (event, context) => {
    for (const record of event.Records) {
        if (record.eventName !== 'INSERT') {
            continue;
        }
        
        // Get DynamoDB inserted record object
        var data = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
        console.log('DynamoDB trigger: Table "file" inserted record: ', JSON.stringify(data, null, 2));

        // Image URL(s) for single file
        var imageUrls = [];

        // For "html", scan HTML code to get all image URLs
        switch (data.type) {
            case 'image':
                imageUrls.push(data.url);
                break;
            case 'html':
                imageUrls = imageUrls.concat(getImageUrlsFromHtmlCode(data.content));
                break;
        }

        console.log('imageUrls: ', JSON.stringify(imageUrls, null, 2));
        return; // ------------- DEBUG -------------

        // Download file from URL, and upload to S3 bucket
        for (var j in imageUrls){
            var uploadResult = await uploadFileFromUrl(imageUrls[j], aid + '/' + fid);

            if (uploadResult === false) {
                console.error('Failed to download [' + imageUrls[j] + '], or not supported file format.');
                continue;
            }
    
            if (uploadResult.statusCode !== 200) {
                console.error('Failed to upload [' + imageUrls[j] + '] to S3. (Code: ' + uploadResult.statusCode + ')');
                continue;
            }

            if (typeof uploadResult.key === 'undefined' || uploadResult.key === null || uploadResult.key === '') {
                console.error('Failed to upload [' + imageUrls[j] + '] to S3. (No key response)');
                continue;
            }
        }
    }
};

async function uploadFileFromUrl(sourceUrl, targetPath) {
    // Download file from URL (and get file MIME)
    const [fileMime, response] = await Promise.all([
        fileType.fromStream(got.stream(sourceUrl)),
        request({
            uri: sourceUrl,
            encoding: null
        })
    ]);

    // Failed to download file, or file format not supported
    if (fileMime === null || response === null) {
        return false;
    }

    // Upload downloaded file to S3 bucket
    const uploadResult = await s3
        .upload({
            Bucket: bucketName,
            Key: targetPath + '.' + fileMime.ext,
            Body: response,
            ContentType: fileMime.mime,
            ACL: 'public-read'
        })
        .promise();

    return uploadResult;
}

function getImageUrlsFromHtmlCode(html) {
    if (typeof html !== 'string') {
        return [];
    }

    var imageUrls = html.match(/(https?:\/\/.*\.(?:png|jpg|))/ig)
    return Array.isArray(imageUrls) ? [...new Set(imageUrls)] : []; // Array unique
}